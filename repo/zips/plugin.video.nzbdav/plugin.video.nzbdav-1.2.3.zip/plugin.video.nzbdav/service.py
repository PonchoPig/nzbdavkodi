# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 nzbdav contributors

"""NZB-DAV background service — hosts stream proxy and monitors playback."""

import faulthandler
import os
import sys
import threading
from enum import Enum

# Same faulthandler hook as addon.py, but the service runs continuously so
# this catches crashes during the long-lived stream-proxy thread too.
try:
    _fh = open("/tmp/nzbdav-faulthandler-service.log", "a", buffering=1)
    faulthandler.enable(file=_fh, all_threads=True)
except OSError:
    pass

# Add resources/lib/ to sys.path (same as addon.py)
addon_dir = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(addon_dir, "resources", "lib")
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

import xbmc  # noqa: E402
import xbmcaddon  # noqa: E402
import xbmcgui  # noqa: E402
from resources.lib.http_util import notify as _notify  # noqa: E402
from resources.lib.stream_proxy import StreamProxy  # noqa: E402

# Window property keys for IPC between plugin and service
_PROP_STREAM_URL = "nzbdav.stream_url"
_PROP_STREAM_TITLE = "nzbdav.stream_title"
_PROP_ACTIVE = "nzbdav.active"
_PROP_PROXY_PORT = "nzbdav.proxy_port"
_PROP_PROXY_TOKEN = "nzbdav.proxy_token"

_HOME_WINDOW = xbmcgui.Window(10000)
_PLAYER_RUNTIME_ERRORS = (
    AttributeError,
    OSError,
    RuntimeError,
    TypeError,
    ValueError,
)

# Bounds for retry settings. Without clamps, a typo of "99999" would
# wedge the player monitor for ~28 hours between attempts (delay) or
# never give up retrying a permanently-broken stream (max_retries).
# The accepted ranges below cover every realistic recovery scenario:
#   * max_retries: 0 disables retries entirely; 10 already takes >1 minute
#     of cumulative backoff with the default 5 s delay.
#   * retry_delay: 1 s is the smallest poll the service tick can honor;
#     300 s (5 min) gives flaky-network recovery plenty of headroom.
_STREAM_MAX_RETRIES_MIN = 0
_STREAM_MAX_RETRIES_MAX = 10
_STREAM_RETRY_DELAY_MIN = 1
_STREAM_RETRY_DELAY_MAX = 300


def _clamp_int_setting(setting_id, value, lo, hi):
    """Clamp an integer setting and log when user input was out of range.

    Mirrors the helper in ``stream_proxy.py`` / ``resolver.py`` — kept
    as a private duplicate (rather than imported) so ``service.py``
    stays importable in the early service-startup phase before
    ``resources.lib`` is fully wired into ``sys.path`` for some
    embedded Kodi builds.
    """
    clamped = value
    if value < lo:
        clamped = lo
    elif value > hi:
        clamped = hi
    if clamped != value:
        xbmc.log(
            "NZB-DAV: Setting {}={} out of range [{}..{}]; clamping to {}".format(
                setting_id, value, lo, hi, clamped
            ),
            xbmc.LOGWARNING,
        )
    return clamped


class PlaybackState(Enum):
    """State machine for NzbdavPlayer.

    Transitions::

        IDLE -> MONITORING   (new stream signalled via window properties)
        MONITORING -> ERROR  (onPlayBackError fires)
        ERROR -> MONITORING  (retry succeeds — onAVStarted resets)
        ERROR -> IDLE        (max retries exceeded, or retries disabled)
        MONITORING -> IDLE   (onPlayBackStopped or onPlayBackEnded)
    """

    IDLE = "idle"  # No active stream; waiting for next play
    MONITORING = "monitoring"  # Stream is playing; watching for errors
    ERROR = "error"  # Error detected; retry in progress


class NzbdavPlayer(xbmc.Player):
    """Persistent playback monitor running inside the background service.

    Registered once when the service starts and kept alive for the entire Kodi
    session.  The plugin (resolver.py) signals a new stream by writing window
    properties; ``tick()`` is called every second from the service loop to check
    those properties and handle retries.
    """

    def __init__(self, proxy=None):
        super().__init__()
        # ``_state_lock`` serializes read-then-write transitions on the
        # state fields below. Kodi player callbacks (onPlayBackStopped /
        # Ended / Error / AVStarted / Seek) execute on internal Kodi
        # threads while ``tick()`` runs on the service main thread; the
        # GIL makes individual attribute writes atomic but does NOT
        # protect "if state == X: state = Y" sequences. Without the lock
        # a callback could flip state between tick's check and tick's
        # write, e.g. user-stop racing into a retry attempt.
        # ``RLock`` so tick → _retry_playback → onAVStarted on the same
        # thread doesn't self-deadlock. Closes TODO.md §H.2-H16.
        self._state_lock = threading.RLock()
        self._state = PlaybackState.IDLE
        self._stream_url = ""
        self._title = ""
        self._last_position = 0.0
        self._retry_count = 0
        self._av_started = False
        self._play_time = 0.0
        self._monitor = xbmc.Monitor()
        self._proxy = proxy

    def _cleanup_proxy_session(self):
        """Kill any active proxy ffmpeg processes.

        Called from onPlayBackStopped / onPlayBackEnded so a clean stop
        immediately tears down the remux chain instead of leaving ffmpeg
        running until the next prepare_stream call discovers it.
        """
        if self._proxy is None:
            return
        try:
            self._proxy.clear_sessions()
        except _PLAYER_RUNTIME_ERRORS:
            pass

    @staticmethod
    def _read_settings():
        """Read retry settings from addon config (clamped to safe bounds).

        Both ``stream_max_retries`` and ``stream_retry_delay`` are
        unconstrained ``type="number"`` fields in settings.xml; without
        the clamps applied below an unclamped 99999 retry_delay would
        freeze the monitor loop for ~28 h between retries. The clamp
        helper logs the original value at LOGWARNING so users debugging
        "why didn't my stream retry?" see the cause in kodi.log.
        """
        addon = xbmcaddon.Addon("plugin.video.nzbdav")
        enabled = addon.getSetting("stream_auto_retry").lower() == "true"
        max_retries = 3
        retry_delay = 5
        try:
            max_retries = int(addon.getSetting("stream_max_retries"))
        except (ValueError, TypeError):
            pass
        try:
            retry_delay = int(addon.getSetting("stream_retry_delay"))
        except (ValueError, TypeError):
            pass
        max_retries = _clamp_int_setting(
            "stream_max_retries",
            max_retries,
            _STREAM_MAX_RETRIES_MIN,
            _STREAM_MAX_RETRIES_MAX,
        )
        retry_delay = _clamp_int_setting(
            "stream_retry_delay",
            retry_delay,
            _STREAM_RETRY_DELAY_MIN,
            _STREAM_RETRY_DELAY_MAX,
        )
        return enabled, max_retries, retry_delay

    def _check_active(self):
        """Check if the plugin signaled a new stream via window properties."""
        import time

        active = _HOME_WINDOW.getProperty(_PROP_ACTIVE)
        if active != "true":
            return
        with self._state_lock:
            self._stream_url = _HOME_WINDOW.getProperty(_PROP_STREAM_URL)
            self._title = _HOME_WINDOW.getProperty(_PROP_STREAM_TITLE)
            self._state = PlaybackState.MONITORING
            self._retry_count = 0
            self._last_position = 0.0
            self._av_started = False
            # ``time.monotonic()`` rather than ``time.time()`` so an NTP
            # step that lands during the 30 s startup grace can't trip a
            # false "playback never started" notification. Compared
            # against ``time.monotonic()`` in tick() below.
            # TODO.md §H.2-M35.
            self._play_time = time.monotonic()
            title = self._title
        # Clear all three properties — not just ACTIVE — so a future
        # second resolver call that fails before re-writing them
        # (network blip, _play_via_proxy crash) doesn't leak the prior
        # session's URL/title into the next monitor cycle. The values we
        # need are now snapshotted onto self.* fields. TODO.md §H.2-L29.
        for prop in (_PROP_ACTIVE, _PROP_STREAM_URL, _PROP_STREAM_TITLE):
            try:
                _HOME_WINDOW.clearProperty(prop)
            except _PLAYER_RUNTIME_ERRORS:
                pass
        xbmc.log(
            "NZB-DAV: Service monitoring stream '{}'".format(title),
            xbmc.LOGINFO,
        )

    def onAVStarted(self):
        """Reset retry state when playback begins successfully."""
        with self._state_lock:
            if self._state not in (PlaybackState.MONITORING, PlaybackState.ERROR):
                return
            self._retry_count = 0
            self._av_started = True
            self._state = PlaybackState.MONITORING
            title = self._title
        xbmc.log(
            "NZB-DAV: Playback started for '{}'".format(title),
            xbmc.LOGINFO,
        )

    def _clear_stream_properties(self):
        """Erase the IPC window properties for this stream.

        Without this, ``nzbdav.stream_url`` and ``nzbdav.stream_title``
        linger across sessions. A second play whose plugin call fails
        before writing fresh properties would cause the service to pick
        up the previous session's URL/title if ``nzbdav.active="true"``
        is ever re-set by a stale/racing writer.
        """
        for prop in (_PROP_STREAM_URL, _PROP_STREAM_TITLE):
            try:
                _HOME_WINDOW.clearProperty(prop)
            except _PLAYER_RUNTIME_ERRORS:
                pass

    def onPlayBackStopped(self):
        """Mark stream inactive when user stops playback."""
        with self._state_lock:
            if self._state == PlaybackState.IDLE:
                return
            self._state = PlaybackState.IDLE
            title = self._title
        # Cleanup outside the lock — `_cleanup_proxy_session` calls
        # `proxy.clear_sessions()` which kills ffmpeg processes; that
        # must not run while a Kodi callback thread holds the lock or
        # the service tick will block waiting for ffmpeg to exit.
        xbmc.log(
            "NZB-DAV: Playback stopped for '{}'".format(title),
            xbmc.LOGINFO,
        )
        self._cleanup_proxy_session()
        self._clear_stream_properties()

    def onPlayBackEnded(self):
        """Mark stream inactive when playback finishes naturally."""
        with self._state_lock:
            if self._state == PlaybackState.IDLE:
                return
            self._state = PlaybackState.IDLE
            title = self._title
        xbmc.log(
            "NZB-DAV: Playback completed for '{}'".format(title),
            xbmc.LOGINFO,
        )
        self._cleanup_proxy_session()
        self._clear_stream_properties()

    def onPlayBackError(self):
        """Transition to ERROR state. Dialogs are shown from tick().

        Kodi player callbacks run on internal threads — showing a modal dialog
        here could deadlock or freeze the UI. So we only set the state flag
        and let tick() handle user notification on the service loop thread.
        """
        with self._state_lock:
            if self._state != PlaybackState.MONITORING:
                return
            self._state = PlaybackState.ERROR
            title = self._title
            retry_count = self._retry_count
        xbmc.log(
            "NZB-DAV: Playback error for '{}' (retry {})".format(title, retry_count),
            xbmc.LOGERROR,
        )

    def onPlayBackSeek(self, time, seek_offset):
        """Capture the new seek target immediately for retry resume.

        A seek can fail before the 1 Hz service tick gets a chance to refresh
        ``_last_position`` via ``getTime()``. Without this callback the retry
        path falls back to the older saved position and appears to "jump
        backwards" after a failed seek.
        """
        with self._state_lock:
            if self._state not in (PlaybackState.MONITORING, PlaybackState.ERROR):
                return
            try:
                self._last_position = max(0.0, float(time))
            except (TypeError, ValueError):
                pos_failed = True
            else:
                pos_failed = False
            title = self._title
            position = self._last_position
        if pos_failed:
            self._save_position()
            return
        xbmc.log(
            "NZB-DAV: Playback seek for '{}' -> {:.0f}s (offset={:.0f}s)".format(
                title,
                position,
                float(seek_offset),
            ),
            xbmc.LOGINFO,
        )

    def _save_position(self):
        """Save current playback position for resume on retry."""
        try:
            if self.isPlaying():
                position = self.getTime()
            else:
                return
        except _PLAYER_RUNTIME_ERRORS:
            return
        with self._state_lock:
            self._last_position = position

    def _retry_playback(self, max_retries, retry_delay):
        """Attempt to resume playback from last known position."""
        with self._state_lock:
            self._retry_count += 1
            self._state = PlaybackState.MONITORING
            title = self._title
            stream_url = self._stream_url
            position = self._last_position
            retry_count = self._retry_count

        xbmc.log(
            "NZB-DAV: Retrying '{}' from {:.0f}s ({}/{})".format(
                title,
                position,
                retry_count,
                max_retries,
            ),
            xbmc.LOGINFO,
        )
        _notify(
            "NZB-DAV",
            "Reconnecting ({}/{})...".format(retry_count, max_retries),
            5000,
        )

        if self._monitor.waitForAbort(retry_delay):
            return False

        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty("StartOffset", str(position))
        self.play(stream_url, li)

        # Wait for playback to start or fail (10s timeout)
        for _ in range(20):
            with self._state_lock:
                state = self._state
            if state in (PlaybackState.IDLE, PlaybackState.ERROR):
                break
            try:
                if self.isPlaying():
                    return True
            except _PLAYER_RUNTIME_ERRORS:
                pass
            if self._monitor.waitForAbort(0.5):
                return False

        with self._state_lock:
            return self._state != PlaybackState.ERROR

    def tick(self):
        """Called each service loop iteration. Handle retries if needed.

        State reads are all done under ``_state_lock`` so a Kodi
        callback (player thread) can't flip state mid-tick. The lock
        is released around long-running calls (``_save_position``,
        ``_retry_playback``) — those re-acquire internally as needed.
        Closes TODO.md §H.2-H16.
        """
        import time

        self._check_active()

        with self._state_lock:
            state = self._state
        if state == PlaybackState.IDLE:
            return

        # Detect playback that never started (stream error, auth failure, etc.)
        # The timeout has to comfortably exceed the worst-case
        # proxy-side startup latency, which on the fmp4 HLS path is
        # roughly: HlsProducer spawn (~0.1 s) + prepare() early-exit
        # poll (~0.5 s) + ffmpeg analyzeduration (2 s, bumped from 0
        # to fix DTS/TrueHD AV sync) + first init.mp4 + first segment
        # write (~0.5 s) + Kodi HLS demuxer + decoder init (~1-3 s).
        # That can land at 4-6 s on the test box even when everything
        # is healthy. The previous 5 s threshold was tripping before
        # Kodi could fire onAVStarted on the new fmp4 path. 30 s
        # gives all the legitimate paths headroom while still
        # catching genuinely dead streams within a reasonable window.
        # The three error paths below used to call ``xbmcgui.Dialog().ok()``
        # which is a *modal* dialog — it blocks the calling thread until
        # the user dismisses it. The service tick runs at ~1 Hz, so a
        # modal here meant the entire monitor loop (heartbeat, abort
        # detection, state transitions) was wedged for as long as the
        # user was away from the TV. Switched to ``_notify`` (a toast via
        # ``xbmc.executebuiltin("Notification(...)")``) which is
        # fire-and-forget. Each path still logs the underlying error
        # at ``LOGERROR``, so a user investigating later via kodi.log
        # gets the same context that the modal would have shown.
        # Closes TODO.md §H.2-H8.
        with self._state_lock:
            in_startup_grace = (
                self._state == PlaybackState.MONITORING and not self._av_started
            )
            play_time = self._play_time
            title = self._title

        if in_startup_grace:
            elapsed = time.monotonic() - play_time
            if elapsed > 30 and not self.isPlaying():
                xbmc.log(
                    "NZB-DAV: Playback never started for '{}' after {:.0f}s".format(
                        title, elapsed
                    ),
                    xbmc.LOGERROR,
                )
                from resources.lib.i18n import addon_name as _addon_name
                from resources.lib.i18n import string as _s

                _notify(_addon_name(), _s(30121), 8000)
                xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                self._cleanup_proxy_session()
                with self._state_lock:
                    self._state = PlaybackState.IDLE
                return

        self._save_position()

        with self._state_lock:
            state = self._state
            retry_count = self._retry_count
            title = self._title
        if state != PlaybackState.ERROR:
            return

        enabled, max_retries, retry_delay = self._read_settings()
        if not enabled:
            from resources.lib.i18n import addon_name as _addon_name
            from resources.lib.i18n import string as _s

            _notify(_addon_name(), _s(30115), 8000)
            with self._state_lock:
                self._state = PlaybackState.IDLE
            return

        if retry_count >= max_retries:
            xbmc.log(
                "NZB-DAV: Max retries ({}) reached for '{}'".format(max_retries, title),
                xbmc.LOGERROR,
            )
            from resources.lib.i18n import addon_name as _addon_name
            from resources.lib.i18n import fmt as _f

            _notify(_addon_name(), _f(30116, max_retries), 8000)
            with self._state_lock:
                self._state = PlaybackState.IDLE
            return

        if not self._retry_playback(max_retries, retry_delay):
            with self._state_lock:
                self._state = PlaybackState.IDLE


def check_cache_warning(state):
    """Compatibility no-op for the retired cache warning.

    Large non-MP4 pass-through is now the default even when Kodi cache=0 is
    absent, so the old warning has no state to mutate and no notification to
    show. ``state`` is accepted only to keep existing imports and service-loop
    wiring harmless.
    """
    return None


def main():
    """Service entry point — runs for the lifetime of Kodi."""
    monitor = xbmc.Monitor()

    # Clear any nzbdav.* IPC window properties left behind by a previous
    # service that didn't shut down cleanly (Kodi crash, force-stop, etc).
    # Window 10000 (Home) properties survive across the Kodi restart that
    # kills the service, so a stale `nzbdav.active="true"` would cause
    # this service's first tick to immediately enter MONITORING with the
    # prior session's stream metadata. Drop them on entry so the new
    # service starts from a clean slate. TODO.md §H.2-M34.
    for stale_prop in (
        _PROP_ACTIVE,
        _PROP_STREAM_URL,
        _PROP_STREAM_TITLE,
        _PROP_PROXY_TOKEN,
    ):
        try:
            _HOME_WINDOW.clearProperty(stale_prop)
        except Exception:  # noqa: BLE001 — best-effort, never block startup
            pass

    # Start the stream proxy in this long-lived service process.
    # Plugin scripts are short-lived — their daemon threads get killed
    # when Kodi's CPythonInvoker destroys the interpreter after the script
    # exits, so the proxy must live here instead.
    proxy = StreamProxy()
    try:
        proxy.start()
    except Exception as e:  # pylint: disable=broad-except
        # Socket bind failure (port in use), permission error, or any other
        # startup exception. Without this guard the service dies silently
        # and every plugin-side /prepare call hangs on "connection refused"
        # with no hint in the log. Surface it clearly, clear the port
        # property so plugin callers fall back quickly, and keep the service
        # alive so the user can fix the config and trigger a re-run.
        xbmc.log(
            "NZB-DAV: Service failed to start stream proxy: {}".format(e),
            xbmc.LOGERROR,
        )
        _HOME_WINDOW.clearProperty(_PROP_PROXY_PORT)
        _HOME_WINDOW.clearProperty(_PROP_PROXY_TOKEN)
        # Idle-loop until Kodi shuts down so the service process stays alive;
        # otherwise Kodi keeps restarting us every few seconds and spams the
        # log with the same start failure.
        while not monitor.abortRequested():
            if monitor.waitForAbort(5):
                break
        return
    _HOME_WINDOW.setProperty(_PROP_PROXY_PORT, str(proxy.port))
    _HOME_WINDOW.setProperty(_PROP_PROXY_TOKEN, proxy.prepare_token)

    # Pass the proxy to the player so stop/end callbacks can tear down
    # active remux ffmpeg processes immediately instead of leaving them
    # running until the next prepare_stream call.
    player = NzbdavPlayer(proxy=proxy)
    xbmc.log(
        "NZB-DAV: Service started (proxy on port {})".format(proxy.port),
        xbmc.LOGINFO,
    )

    # Track consecutive tick failures so we can escalate a chronic bug
    # from "log once per tick" (flooding the log with the same trace) to
    # a one-shot "service is unhealthy, please file an issue" warning.
    consecutive_tick_failures = 0

    # Retained for the no-op check_cache_warning compatibility hook.
    cache_warn_state = {
        "last_mode": None,
    }

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

        # Proxy health check: the HTTP server runs in a daemon thread.
        # If the serve_forever loop ever exits (unhandled exception,
        # socket error, rare memory-pressure path), every subsequent
        # /prepare call from the plugin side hangs on "connection
        # refused" with no log hint and no recovery. Detect the dead
        # thread and rebuild the proxy so streams keep working.
        if not proxy.is_alive():
            xbmc.log(
                "NZB-DAV: Stream proxy thread is dead; restarting "
                "(reason=proxy_thread_died)",
                xbmc.LOGERROR,
            )
            try:
                proxy.stop()
            except Exception as e:  # pylint: disable=broad-except
                # Logged at LOGWARNING (not LOGERROR) because we're about
                # to spawn a fresh proxy anyway — the stop failure is
                # diagnostic-only, not user-actionable. Closes §H.3.
                xbmc.log(
                    "NZB-DAV: proxy.stop() raised during restart "
                    "(continuing): {!r}".format(e),
                    xbmc.LOGWARNING,
                )
            proxy = StreamProxy()
            try:
                proxy.start()
            except Exception as e:  # pylint: disable=broad-except
                xbmc.log(
                    "NZB-DAV: Stream proxy restart failed: {} "
                    "(reason=proxy_restart_failed)".format(e),
                    xbmc.LOGERROR,
                )
                _HOME_WINDOW.clearProperty(_PROP_PROXY_PORT)
                _HOME_WINDOW.clearProperty(_PROP_PROXY_TOKEN)
            else:
                _HOME_WINDOW.setProperty(_PROP_PROXY_PORT, str(proxy.port))
                _HOME_WINDOW.setProperty(_PROP_PROXY_TOKEN, proxy.prepare_token)
                # The player holds a reference to the old proxy for
                # cleanup calls from onPlayBackStopped; point it at the
                # new one so the next stop() fires on the live proxy.
                player._proxy = proxy  # pylint: disable=protected-access
                xbmc.log(
                    "NZB-DAV: Stream proxy restarted on port {}".format(proxy.port),
                    xbmc.LOGINFO,
                )

        try:
            check_cache_warning(cache_warn_state)
        except Exception as e:  # pylint: disable=broad-except
            # Never let a settings-read glitch take down the service loop.
            xbmc.log(
                "NZB-DAV: cache warning check failed: {}".format(e),
                xbmc.LOGERROR,
            )

        try:
            player.tick()
            consecutive_tick_failures = 0
        except Exception as e:  # pylint: disable=broad-except
            # A crash inside tick() used to kill the whole service,
            # silently breaking all future streams until Kodi restart.
            # Absorb it so the loop keeps running. Rate-limit the full
            # trace to the first failure of a streak; subsequent
            # failures log a single line with the streak counter so a
            # chronic bug is visible without flooding the log.
            consecutive_tick_failures += 1
            if consecutive_tick_failures == 1:
                xbmc.log(
                    "NZB-DAV: Unhandled exception in player.tick(): {} "
                    "(reason=tick_exception)".format(e),
                    xbmc.LOGERROR,
                )
            else:
                xbmc.log(
                    "NZB-DAV: player.tick() still failing "
                    "(streak={}, latest={})".format(consecutive_tick_failures, e),
                    xbmc.LOGERROR,
                )

    # Guard the shutdown stop the same way the restart path does.
    # Without the guard, an exception in `proxy.stop()` (socket already
    # closed, thread join timeout, etc.) would skip the
    # `clearProperty(_PROP_PROXY_PORT)` line and leave a stale port
    # visible to the next service launch — clients would then connect
    # to a dead port. TODO.md §H.2-M36.
    try:
        proxy.stop()
    except Exception as e:  # pylint: disable=broad-except
        xbmc.log(
            "NZB-DAV: proxy.stop() raised during shutdown "
            "(continuing): {!r}".format(e),
            xbmc.LOGWARNING,
        )
    _HOME_WINDOW.clearProperty(_PROP_PROXY_PORT)
    _HOME_WINDOW.clearProperty(_PROP_PROXY_TOKEN)
    xbmc.log("NZB-DAV: Service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    main()
